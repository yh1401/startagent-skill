"""
parsers.py - Log format parsers for log-analyzer-skill.
Auto-detects and parses common log formats (ISO, Syslog, NCSA, Java stack).
Zero external dependencies.
"""

import re
from typing import Optional, Dict, Any, List, Tuple

# ── Log level set ──
LOG_LEVELS = {"TRACE", "DEBUG", "INFO", "WARN", "WARNING", "ERROR", "FATAL", "CRITICAL"}

# ── Format definitions ──
# Order matters: more specific patterns must come first
FORMAT_PATTERNS: List[Tuple[str, re.Pattern]] = [
    # Java/Spring log: timestamp [thread] LEVEL trace_id class_name - message
    # e.g. 2024-01-01 12:00:00.123 [http-nio-8080-exec-1] ERROR a1b2c3d4e5f6 com.example.Service - NullPointerException
    ("java_app", re.compile(
        r'^(?P<ts>\d{4}[-/]\d{2}[-/]\d{2}[T ]\d{2}:\d{2}:\d{2}(?:[.,]\d{3})?)'
        r'\s+\[(?P<thread>[^\]]+)\]'
        r'\s+(?P<level>TRACE|DEBUG|INFO|WARN(?:ING)?|ERROR|FATAL|CRITICAL)\b'
        r'\s+(?P<trace_id>[a-fA-F0-9-]+)?\s*'
        r'(?P<module>[\w.]+\.[\w.]+)?'
        r'\s*[:\-]?\s*(?P<message>.+)?',
        re.IGNORECASE
    )),

    # ISO-8601 / standard timestamp: [2024-01-01 12:00:00,123] LEVEL [module] message
    ("iso", re.compile(
        r'^\[?(?P<ts>\d{4}[-/]\d{2}[-/]\d{2}[T ]\d{2}:\d{2}:\d{2}(?:[.,]\d{3})?)\]?\s+'
        r'(?P<level>TRACE|DEBUG|INFO|WARN(?:ING)?|ERROR|FATAL|CRITICAL)\b'
        r'(?:\s+\[?(?P<module>[^\]]+)\]?)?'
        r'\s*[:\-]?\s*(?P<message>.+)',
        re.IGNORECASE
    )),

    # Syslog
    ("syslog", re.compile(
        r'^(?:<\d+>)?'
        r'(?P<ts>[A-Z][a-z]{2}\s+\d{1,2}\s+\d{2}:\d{2}:\d{2}(?:\.\d+)?)'
        r'\s+\S+\s+(?P<module>\S+?)(?:\[\d+\])?:\s*'
        r'(?P<level>TRACE|DEBUG|INFO|WARN(?:ING)?|ERROR|FATAL)\s*'
        r'[:\-]?\s*(?P<message>.+)?',
        re.IGNORECASE
    )),

    # NCSA / Common Log Format (Apache/Nginx access log)
    ("ncsa", re.compile(
        r'^(?P<remote>\S+)\s+\S+\s+\S+\s+'
        r'\[(?P<ts>\d{2}/\w{3}/\d{4}:\d{2}:\d{2}:\d{2}\s[+-]\d{4})\]'
        r'\s+"(?P<method>\S+)\s+(?P<path>\S+)\s+\S+"\s+'
        r'(?P<status>\d{3})\s+(?P<size>\d+|-)',
    )),

    # Java stack trace line (continuation lines after exception)
    ("java_stack", re.compile(
        r'^\s+at\s+[\w.$]+\([\w.]+\.java:\d+\)',
    )),

    # Caused by: line
    ("caused_by", re.compile(
        r'^Caused by:\s+(?P<exception>[\w.]+(?:Exception|Error)):\s*(?P<message>.*)',
    )),
]


def detect_format(line: str) -> Optional[str]:
    """Auto-detect which log format a line belongs to."""
    if not line.strip():
        return None
    for name, pattern in FORMAT_PATTERNS:
        if pattern.match(line):
            return name
    return None


def parse_line(line: str) -> Optional[Dict[str, Any]]:
    """
    Parse a single log line into a structured record.
    Returns None for unrecognized lines (continuation lines, blank lines, etc.)
    """
    stripped = line.strip("\n\r")
    if not stripped:
        return None

    for name, pattern in FORMAT_PATTERNS:
        m = pattern.match(stripped)
        if not m:
            continue

        record: Dict[str, Any] = {
            "_raw": line,
            "_format": name,
            "_line_no": 0,
        }
        gd = m.groupdict()

        # Extract level
        level_raw = gd.get("level", "")
        if level_raw:
            record["level"] = level_raw.upper()
        elif name == "ncsa":
            status = int(gd.get("status", 0))
            if status >= 500:
                record["level"] = "ERROR"
            elif status >= 400:
                record["level"] = "WARN"
            else:
                record["level"] = "INFO"

        # Extract timestamp
        ts_raw = gd.get("ts")
        if ts_raw:
            record["timestamp"] = _parse_timestamp(ts_raw, name)
            record["timestamp_raw"] = ts_raw

        # Extract message
        msg = gd.get("message", "").strip()
        if msg:
            record["message"] = msg

        # Module/class info
        mod = gd.get("module")
        if mod:
            record["module"] = mod.strip("[] ")

        # Thread name (java_app format)
        thread = gd.get("thread")
        if thread:
            record["thread_name"] = thread

        # Trace ID (java_app format)
        trace_id = gd.get("trace_id")
        if trace_id:
            record["trace_id"] = trace_id

        # HTTP-specific
        if name == "ncsa":
            record["http_method"] = gd.get("method", "")
            record["http_path"] = gd.get("path", "")
            record["http_status"] = int(gd.get("status", 0))
            record["remote_addr"] = gd.get("remote", "")
            record["message"] = f'{gd.get("method","")} {gd.get("path","")} -> {gd.get("status","")}'

        if name == "caused_by":
            record["exception"] = gd.get("exception", "")
            record["is_root_cause"] = True

        if name == "java_stack":
            record["is_stack_trace"] = True

        # Extract error type from message (only for error-level records)
        level = record.get("level", "")
        if level in ("ERROR", "FATAL", "CRITICAL"):
            record["error_type"] = _extract_error_type(record.get("message", ""))
            record["error_message"] = _extract_error_message(record.get("message", ""))
        else:
            record["error_type"] = None
            record["error_message"] = None

        return record

    return None


def _extract_error_type(message: str) -> str:
    """Extract error type (Exception/Error class name) from message."""
    m = re.search(r'([\w.]+(?:Exception|Error|Fault))', message)
    if m:
        return m.group(1)
    # Fallback: check for known error keywords
    if re.search(r'(timeout|超时)', message, re.IGNORECASE):
        return "TimeoutError"
    if re.search(r'(refused|connection.*reset)', message, re.IGNORECASE):
        return "ConnectionError"
    if re.search(r'(denied|permission|access)', message, re.IGNORECASE):
        return "PermissionError"
    if re.search(r'(null|npe)', message, re.IGNORECASE):
        return "NullPointerError"
    return "UnknownError"


def _extract_error_message(message: str) -> str:
    """Extract the meaningful part of an error message."""
    # Try to get text after exception class name
    m = re.search(r'(?:Exception|Error|Fault)[:\s]+(.+?)$', message)
    if m:
        return m.group(1).strip()
    return message[:200]


def _parse_timestamp(raw: str, fmt_name: str) -> Optional[str]:
    """Parse timestamp into ISO-8601 string."""
    try:
        if fmt_name == "iso":
            ts = raw.replace("/", "-").replace("T", " ").replace(",", ".")
            return ts[:26] if "." in ts else ts[:19]

        elif fmt_name == "syslog":
            from datetime import datetime
            return datetime.strptime(raw, "%b %d %H:%M:%S").replace(
                year=datetime.now().year
            ).isoformat()

        elif fmt_name == "ncsa":
            from datetime import datetime
            return datetime.strptime(raw[:20], "%d/%b/%Y:%H:%M:%S").isoformat()
    except (ValueError, IndexError):
        pass
    return None


def is_stack_trace_line(line: str) -> bool:
    """Check if a line is a Java stack continuation line."""
    return bool(re.match(r'^\s+at\s+', line)) or bool(re.match(r'^\.\.\.\s+\d+\s+more', line))
