#!/usr/bin/env python3
"""
Log Analyzer - 自包含的日志解析与分析脚本

零外部依赖（仅可选 pyyaml），可在任何 Python 3.8+ 环境运行。
支持 GB 级大文件流式解析、错误统计、趋势分析。

用法:
    python src/analyze_log.py --file <日志文件路径> [选项]

输出:
    结构化 JSON，可直接作为 LLM 分析的输入

示例:
    python src/analyze_log.py --file /var/log/app.log
    python src/analyze_log.py --file /var/log/app.log --chunk-size 200000
    python src/analyze_log.py --file /var/log/app.log --output markdown
"""

import os
import re
import sys
import json
import time
import argparse
from datetime import datetime
from collections import Counter, defaultdict
from typing import Optional, List, Dict, Any


# ──────────────────────────────────────────────
# 日志解析正则
# ──────────────────────────────────────────────

LOG_PATTERN = re.compile(
    r'^(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}\.\d{3})'  # 1: timestamp
    r'\s+\[([^\]]+)\]'                                      # 2: thread name
    r'\s+(\w+)'                                             # 3: log level
    r'\s+([a-f0-9-]+)'                                      # 4: trace_id/uuid
    r'\s+([\w\.]+)'                                         # 5: class name
    r'\s+-\s+(.*)$'                                         # 6: message
)

ERROR_EXTRACT = re.compile(r'([\w\.]+(?:Exception|Error|Fault))(?::\s*(.*)|(?:\s+(.*)))?$')

# 自定义错误模式（可按需扩展）
CUSTOM_PATTERNS: Dict[str, Dict[str, str]] = {
    "null_pointer":      {"regex": r"null|NullPointer|NPE",                           "severity": "critical"},
    "timeout":           {"regex": r"timeout|超时|timed? ?out|Timeout",               "severity": "high"},
    "database_error":    {"regex": r"SQLException|SQL.*error|数据库|Database.*error", "severity": "high"},
    "network_error":     {"regex": r"Network.*error|ConnectException|refused",        "severity": "medium"},
    "authentication":    {"regex": r"auth|token.*invalid|认证.*失败|permission",       "severity": "high"},
    "validation_error":  {"regex": r"validation|参数.*错误|不能为空|必填",              "severity": "medium"},
    "memory_error":      {"regex": r"OutOfMemory|memory|heap|StackOverflow",           "severity": "critical"},
}

# 严重级别排序
SEVERITY_ORDER = {"critical": 0, "high": 1, "medium": 2, "low": 3}

# ──────────────────────────────────────────────
# 数据结构
# ──────────────────────────────────────────────

class ParsedEntry:
    """单条日志条目的解析结果"""
    __slots__ = ('timestamp', 'thread_name', 'level', 'trace_id',
                 'class_name', 'message', 'raw_line', 'line_number',
                 'error_type', 'error_message')

    def __init__(self, timestamp: str, thread_name: str, level: str,
                 trace_id: str, class_name: str, message: str,
                 raw_line: str, line_number: int):
        self.timestamp = timestamp
        self.thread_name = thread_name
        self.level = level.upper()
        self.trace_id = trace_id
        self.class_name = class_name
        self.message = message
        self.raw_line = raw_line
        self.line_number = line_number
        self.error_type = None
        self.error_message = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "timestamp": self.timestamp,
            "level": self.level,
            "error_type": self.error_type or "UnknownError",
            "error_message": self.error_message or self.message[:200],
            "class_name": self.class_name,
            "thread_name": self.thread_name,
            "trace_id": self.trace_id,
        }


# ──────────────────────────────────────────────
# 核心解析器
# ──────────────────────────────────────────────

class LogParser:
    """大文件日志解析器，支持 mmap 流式解析"""

    def __init__(self, chunk_size: int = 100000):
        self.chunk_size = chunk_size
        self._line_count = 0
        self._parse_error_count = 0

    def parse_file(self, file_path: str) -> Dict[str, Any]:
        """
        解析日志文件，返回完整的统计和分析结果。

        Args:
            file_path: 日志文件路径

        Returns:
            包含统计数据、错误样本、时间线的字典
        """
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"文件不存在: {file_path}")

        file_size = os.path.getsize(file_path)
        start_time = time.time()

        # 收集所有条目（分块处理，但先全部解析以获取完整统计）
        all_errors: List[ParsedEntry] = []
        total_lines = 0

        try:
            with open(file_path, 'r', encoding='utf-8', errors='replace') as f:
                for line in f:
                    total_lines += 1
                    entry = self._parse_line(line, total_lines)
                    if entry is None:
                        continue
                    # 只保留 ERROR / FATAL / WARN
                    if entry.level in ('ERROR', 'FATAL'):
                        all_errors.append(entry)
        except MemoryError:
            # 如果一次性读取失败，改用 mmap
            return self._parse_file_mmap(file_path)
        except (OSError, IOError) as e:
            raise IOError(f"读取文件失败: {e}")

        parse_time = time.time() - start_time

        # 构建统计结果
        result = self._build_result(
            file_path=file_path,
            file_size=file_size,
            total_lines=total_lines,
            all_errors=all_errors,
            parse_time=parse_time,
        )
        return result

    def _parse_file_mmap(self, file_path: str) -> Dict[str, Any]:
        """使用 mmap 方式解析大文件"""
        file_size = os.path.getsize(file_path)
        start_time = time.time()
        all_errors: List[ParsedEntry] = []
        total_lines = 0

        with open(file_path, 'r', encoding='utf-8', errors='replace') as f:
            # mmap 对大文件更友好
            import mmap
            with mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ) as mm:
                for line in iter(mm.readline, b''):
                    total_lines += 1
                    decoded = line.decode('utf-8', errors='replace')
                    entry = self._parse_line(decoded, total_lines)
                    if entry and entry.level in ('ERROR', 'FATAL'):
                        all_errors.append(entry)

        parse_time = time.time() - start_time
        result = self._build_result(
            file_path=file_path,
            file_size=file_size,
            total_lines=total_lines,
            all_errors=all_errors,
            parse_time=parse_time,
        )
        return result

    def _parse_line(self, line: str, line_number: int) -> Optional[ParsedEntry]:
        """解析单行日志"""
        line = line.rstrip('\n\r')
        if not line:
            return None

        m = LOG_PATTERN.match(line)
        if not m:
            return None

        timestamp, thread_name, level, trace_id, class_name, message = m.groups()
        entry = ParsedEntry(
            timestamp=timestamp,
            thread_name=thread_name,
            level=level,
            trace_id=trace_id,
            class_name=class_name,
            message=message,
            raw_line=line,
            line_number=line_number,
        )

        # 提取错误类型
        err_m = ERROR_EXTRACT.search(message)
        if err_m:
            entry.error_type = err_m.group(1)
            entry.error_message = (err_m.group(2) or err_m.group(3) or "").strip()
        else:
            entry.error_type = "UnknownError"
            entry.error_message = message[:200]

        return entry

    def _build_result(self, file_path: str, file_size: int,
                      total_lines: int, all_errors: List[ParsedEntry],
                      parse_time: float) -> Dict[str, Any]:
        """构建最终输出结果"""
        # 按级别统计
        level_counter = Counter(e.level for e in all_errors)

        # 按错误类型统计
        error_type_counter = Counter(e.error_type or "UnknownError" for e in all_errors)

        # 按类名统计
        class_counter = Counter(e.class_name for e in all_errors)

        # 错误样本（取前 50 条）
        sample_count = min(len(all_errors), 50)
        error_samples = [all_errors[i].to_dict() for i in range(sample_count)]

        # 时间线
        timeline = self._build_timeline(all_errors)

        # 错误模式匹配
        pattern_matches = self._match_patterns(all_errors)

        # 严重程度评估
        severity_stats = self._evaluate_severity(all_errors)

        lines_per_sec = total_lines / parse_time if parse_time > 0 else 0

        return {
            "file_info": {
                "path": os.path.abspath(file_path),
                "size_mb": round(file_size / (1024 * 1024), 2),
                "total_lines": total_lines,
            },
            "statistics": {
                "by_level": dict(level_counter),
                "error_types": dict(error_type_counter.most_common(50)),
                "top_classes": dict(class_counter.most_common(50)),
            },
            "error_samples": error_samples,
            "error_timeline": timeline,
            "pattern_matches": pattern_matches,
            "severity_distribution": severity_stats,
            "total_errors": len(all_errors),
            "total_warnings": level_counter.get('WARN', 0),
            "performance": {
                "parse_time_seconds": round(parse_time, 3),
                "lines_per_second": round(lines_per_sec, 2),
            },
        }

    def _build_timeline(self, entries: List[ParsedEntry]) -> Dict[str, Any]:
        """构建错误时间线"""
        if not entries:
            return {
                "first_error": None,
                "last_error": None,
                "peak_window": None,
                "time_buckets": {},
                "total_span_minutes": 0,
            }

        first = entries[0].timestamp
        last = entries[-1].timestamp

        # 按时间窗口分组（15分钟一个桶）
        buckets: Dict[str, int] = defaultdict(int)
        for e in entries:
            if e.timestamp and len(e.timestamp) >= 16:
                # 取到分钟级别，然后计算到15分钟桶
                try:
                    dt = datetime.strptime(e.timestamp[:19], "%Y-%m-%d %H:%M:%S")
                    minute = dt.minute // 15 * 15
                    bucket_key = f"{dt.hour:02d}:{minute:02d}"
                    buckets[bucket_key] += 1
                except ValueError:
                    buckets["unknown"] += 1

        # 找高峰窗口
        peak_bucket = max(buckets, key=buckets.get) if buckets else None
        peak_count = buckets.get(peak_bucket, 0) if peak_bucket else 0

        return {
            "first_error": first,
            "last_error": last,
            "peak_window": {
                "time": peak_bucket,
                "error_count": peak_count,
            } if peak_bucket else None,
            "time_buckets": dict(sorted(buckets.items())),
        }

    def _match_patterns(self, entries: List[ParsedEntry]) -> Dict[str, int]:
        """匹配预定义的错误模式"""
        matches: Dict[str, int] = defaultdict(int)
        for e in entries:
            for pattern_name, pattern_info in CUSTOM_PATTERNS.items():
                if re.search(pattern_info["regex"], e.message, re.IGNORECASE):
                    matches[pattern_name] += 1
                    break
        return dict(matches)

    def _evaluate_severity(self, entries: List[ParsedEntry]) -> Dict[str, int]:
        """评估错误的严重程度分布"""
        severity: Dict[str, int] = {"critical": 0, "high": 0, "medium": 0, "low": 0}
        for e in entries:
            assigned = False
            for pattern_name, pattern_info in CUSTOM_PATTERNS.items():
                if re.search(pattern_info["regex"], e.message, re.IGNORECASE):
                    sev = pattern_info["severity"]
                    severity[sev] += 1
                    assigned = True
                    break
            if not assigned:
                # 默认根据日志级别
                if e.level == 'FATAL':
                    severity["critical"] += 1
                elif e.level == 'ERROR':
                    severity["high"] += 1
                else:
                    severity["medium"] += 1
        return severity


# ──────────────────────────────────────────────
# Markdown 报告生成
# ──────────────────────────────────────────────

def to_markdown(result: Dict[str, Any]) -> str:
    """将解析结果转为 Markdown 报告"""
    fi = result["file_info"]
    stats = result["statistics"]
    perf = result["performance"]
    tl = result["error_timeline"]

    lines = []
    lines.append(f"# 日志分析报告 - {os.path.basename(fi['path'])}")
    lines.append(f"**生成时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    lines.append(f"**文件**: {fi['path']}")
    lines.append(f"**文件大小**: {fi['size_mb']} MB")
    lines.append(f"**总行数**: {fi['total_lines']:,}")
    lines.append(f"**总错误数**: {result['total_errors']:,}")
    lines.append(f"**总警告数**: {result['total_warnings']:,}")
    lines.append("")

    # 性能
    lines.append("## 1. 处理概览")
    lines.append(f"**解析耗时**: {perf['parse_time_seconds']} 秒")
    lines.append(f"**处理速度**: {perf['lines_per_second']:,.0f} 行/秒")
    lines.append("")

    # 错误级别分布
    lines.append("## 2. 统计分析")
    lines.append("### 错误级别分布")
    for level, count in sorted(stats["by_level"].items()):
        if count > 0:
            lines.append(f"- **{level}**: {count:,}")
    lines.append("")

    # 错误类型
    if stats["error_types"]:
        lines.append("### 错误类型统计 (Top 20)")
        for err_type, count in list(stats["error_types"].items())[:20]:
            lines.append(f"- {err_type}: {count:,}")
        lines.append("")

    # 高频类
    if stats["top_classes"]:
        lines.append("### 高频错误类 (Top 20)")
        for cls, count in list(stats["top_classes"].items())[:20]:
            lines.append(f"- {cls}: {count:,}")
        lines.append("")

    # 错误模式
    if result.get("pattern_matches"):
        lines.append("### 错误模式匹配")
        for pattern, count in sorted(result["pattern_matches"].items(),
                                      key=lambda x: -x[1]):
            lines.append(f"- **{pattern}**: {count:,}")
        lines.append("")

    # 严重程度
    if result.get("severity_distribution"):
        lines.append("### 严重程度分布")
        for sev in ("critical", "high", "medium", "low"):
            count = result["severity_distribution"].get(sev, 0)
            if count > 0:
                lines.append(f"- **{sev}**: {count:,}")
        lines.append("")

    # 时间线
    lines.append("## 3. 时间线分析")
    lines.append(f"**首次错误**: {tl['first_error'] or '无'}")
    lines.append(f"**最后错误**: {tl['last_error'] or '无'}")
    if tl.get("peak_window") and tl["peak_window"].get("time"):
        pw = tl["peak_window"]
        lines.append(f"**错误高峰**: {pw['time']} ({pw['error_count']:,} 次)")
    lines.append("")

    if tl.get("time_buckets"):
        lines.append("### 时间窗口分布")
        lines.append("| 时间窗口 | 错误数 |")
        lines.append("|----------|--------|")
        for bucket, count in sorted(tl["time_buckets"].items()):
            bar = "█" * min(count // 5, 40)
            lines.append(f"| {bucket} | {count:,} {bar} |")
        lines.append("")

    # 错误样本
    if result.get("error_samples"):
        lines.append("## 4. 错误样本 (Top 20)")
        lines.append("| # | 时间 | 错误类型 | 类名 | 消息 |")
        lines.append("|---|------|----------|------|------|")
        for i, sample in enumerate(result["error_samples"][:20], 1):
            msg = sample.get("error_message", "")[:80]
            lines.append(f"| {i} | {sample['timestamp']} | {sample['error_type']} | "
                         f"{sample['class_name']} | {msg} |")
        lines.append("")

    # 摘要
    lines.append("## 5. 总体摘要")
    summary = (
        f"共发现 {result['total_errors']:,} 条错误记录，涉及 "
        f"{len(stats['error_types'])} 种错误类型。"
    )
    if stats["error_types"]:
        top_error = list(stats["error_types"].items())[0]
        summary += f" 最频繁的错误是 {top_error[0]}，出现 {top_error[1]:,} 次。"
    lines.append(summary)
    lines.append("")

    return "\n".join(lines)


# ──────────────────────────────────────────────
# 主入口
# ──────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="日志文件深度分析工具（自包含版本）",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
使用示例:
  %(prog)s --file /var/log/app.log
  %(prog)s --file /var/log/app.log --chunk-size 200000 --output markdown
  %(prog)s --file /var/log/app.log --output json
        """,
    )
    parser.add_argument('--file', '-f', type=str, required=True,
                        help='日志文件路径')
    parser.add_argument('--chunk-size', '-c', type=int, default=100000,
                        help='分块大小（行数），默认 100000')
    parser.add_argument('--output', '-o', type=str, default='json',
                        choices=['json', 'markdown', 'md'],
                        help='输出格式：json / markdown（默认 json）')

    args = parser.parse_args()

    # Windows 路径编码处理
    file_path = args.file
    if sys.platform == 'win32' and not os.path.exists(file_path):
        # 尝试用 Unicode 方式读取路径
        try:
            file_path = str(args.file)
        except UnicodeEncodeError:
            pass

    if not os.path.exists(file_path):
        print(json.dumps({
            "error": True,
            "message": f"文件不存在: {file_path}",
        }, ensure_ascii=False))
        sys.exit(1)

    try:
        log_parser = LogParser(chunk_size=args.chunk_size)
        result = log_parser.parse_file(file_path)

        if args.output in ('markdown', 'md'):
            print(to_markdown(result))
        else:
            print(json.dumps(result, ensure_ascii=False, indent=2))

    except Exception as e:
        print(json.dumps({
            "error": True,
            "message": str(e),
        }, ensure_ascii=False))
        sys.exit(1)


if __name__ == '__main__':
    main()
