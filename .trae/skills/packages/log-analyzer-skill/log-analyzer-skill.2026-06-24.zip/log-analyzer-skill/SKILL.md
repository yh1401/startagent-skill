---
name: log-analyzer-skill
description: 日志文件深度分析工具，支持大文件流式解析、错误统计、根因推断及多格式报告生成。当用户提供日志文件路径或需要分析错误日志时调用。
version: 2.0.0
author: dev-team
---

# Log Analyzer Skill

## 技能概述

本技能是一个**平台无关**的日志分析工具，可以在任何支持自然语言工具调用的 Agent 平台（Dify、LangChain、OpenCode 等）上运行。

**核心设计原则**：
- 日志文件的**解析/分块/统计**由自包含的 Python 脚本完成（仅依赖 stdlib + pyyaml）
- 日志的**深度分析/根因推断/报告生成**由平台的 LLM 使用内置的专家提示词完成
- 大文件采用**流式分块处理**，内存占用稳定

## 能力矩阵

| 能力 | 实现方式 | 说明 |
|------|---------|------|
| 大文件流式解析 | Python 脚本 | mmap + 分块，支持 GB 级文件 |
| 错误类型提取 | Python 脚本 | 正则提取 Exception/Error 类型 |
| 错误频率统计 | Python 脚本 | 按级别、类型、类名维度统计 |
| 趋势识别 | Python 脚本 | 时间窗口内的错误频率变化 |
| 根因推断 | LLM 提示词 | 基于证据的因果链分析 |
| 故障时间线 | LLM 提示词 | 按时间序列梳理故障生命周期 |
| 处置建议 | LLM 提示词 | 应急止血、排查定位、恢复验证 |
| 整改建议 | LLM 提示词 | 立即处置、根因解决、架构改进 |
| 报告生成 | LLM 提示词 | JSON 结构化输出 → Markdown 转换 |

## 目录结构

```
.trae/skills/log-analyzer-skill/
├── SKILL.md                  # 本文件 - 技能定义（含完整分析提示词）
├── src/
│   ├── analyze_log.py        # 自包含的日志解析脚本（零外部依赖）
│   └── build_report.py       # 报告生成脚本（将 JSON 转为 Markdown）
└── requirements.txt          # 最小依赖（仅 pyyaml）
```

## 工作流程

```
用户提供日志文件路径
       │
       ▼
步骤1: Python 脚本解析日志
       ├── 流式读取（mmap / 逐行）
       ├── 正则提取字段（时间戳、级别、类名、错误类型）
       ├── 按分块处理（可配置 chunk_size）
       ├── 统计错误分布（按级别、类型、类名）
       └── 输出结构化 JSON
       │
       ▼
步骤2: 将解析结果注入 LLM 提示词
       ├── 错误样本（Top N 条）
       ├── 统计数据（级别分布、类型分布）
       └── 趋势数据（时间窗口统计）
       │
       ▼
步骤3: LLM 使用专家提示词进行分析
       ├── 故障时间线梳理
       ├── 根因推断（直接原因 + 根本原因）
       ├── 因果链与证据链构建
       ├── 处置动作建议
       ├── 整改建议（立即/短期/长期）
       └── 输出 JSON 结构化报告
       │
       ▼
步骤4: 报告输出
       ├── Markdown 报告（默认）
       ├── Word 报告（可选）
       └── PDF 报告（可选）
```

## 工具定义

### 工具 1: parse_log_file

解析日志文件，提取错误信息并返回结构化 JSON 数据，供后续 LLM 分析使用。

**调用方式**：
```bash
python src/analyze_log.py --file <日志路径> [选项]
```

**参数**：

| 参数 | 类型 | 必填 | 默认值 | 说明 |
|------|------|------|--------|------|
| `--file / -f` | string | 是 | - | 日志文件路径 |
| `--chunk-size / -c` | integer | 否 | 100000 | 每块处理行数（大文件建议 50000-200000） |
| `--output / -o` | string | 否 | json | 输出格式：json / markdown |

**输出 JSON 结构**：

```json
{
  "file_info": {
    "path": "/var/log/app.log",
    "size_mb": 128.5,
    "total_lines": 1500000
  },
  "statistics": {
    "by_level": {
      "ERROR": 890,
      "FATAL": 344,
      "WARN": 567,
      "INFO": 1482199,
      "DEBUG": 0
    },
    "error_types": {
      "NullPointerException": 456,
      "SQLException": 234,
      "TimeoutException": 123,
      "IOException": 67
    },
    "top_classes": {
      "com.example.UserService": 345,
      "com.example.OrderController": 234,
      "com.example.DatabaseClient": 123
    }
  },
  "error_samples": [
    {
      "timestamp": "2026-06-14 10:30:45.123",
      "level": "ERROR",
      "error_type": "NullPointerException",
      "error_message": "Cannot invoke method on null object",
      "class_name": "com.example.UserService",
      "thread_name": "http-nio-8080-exec-1",
      "trace_id": "a1b2c3d4e5f6"
    }
  ],
  "error_timeline": {
    "first_error": "2026-06-14 10:00:00.000",
    "last_error": "2026-06-14 11:30:00.000",
    "peak_window": {
      "start": "2026-06-14 10:15:00",
      "end": "2026-06-14 10:45:00",
      "error_count": 567
    },
    "time_buckets": {
      "10:00-10:15": 12,
      "10:15-10:30": 234,
      "10:30-10:45": 333,
      "10:45-11:00": 89,
      "11:00-11:30": 34
    }
  },
  "total_errors": 1234,
  "total_warnings": 567,
  "performance": {
    "parse_time_seconds": 2.34,
    "lines_per_second": 641025
  }
}
```

### 工具 2: 日志深度分析（LLM 提示词）

使用以下系统提示词，结合 `parse_log_file` 输出的 JSON 数据，对日志进行深度分析。

**system_prompt** 见下方「日志分析专家提示词」章节。

**user_content** 示例：
```
错误日志统计:
{
  "by_level": {"ERROR": 890, "FATAL": 344},
  "error_types": {"NullPointerException": 456, "SQLException": 234},
  "top_classes": {"com.example.UserService": 345, ...}
}

错误样本:
[
  {"timestamp": "2026-06-14 10:30:45.123", "error_type": "NullPointerException", ...}
]

请分析以上错误日志并生成 JSON 格式的报告。
```

## 日志分析专家提示词

以下是供 LLM 使用的**系统提示词**，包含完整的分析框架和 JSON Schema 定义：

---

你是一个资深的专业日志分析工程师和故障排查专家，擅长分析应用程序错误日志、定位故障根因、构建证据链，并提供可落地的处置和整改方案。

你的任务是对提供的错误日志数据进行深度分析，生成一份结构化的故障分析总结报告。报告应当专业、准确、可操作。

### 报告结构要求

生成的报告必须包含以下核心环节：

#### 一、故障时间线（Fault Timeline）
按时间顺序梳理故障的完整生命周期，包括：
- **首次异常时间**：第一条异常/错误日志的时间戳
- **故障确认时间**：错误达到阈值或明确表示故障的时间点
- **错误峰值时间**：错误频率最高或影响最大的时间段
- **故障恢复时间**：第一条恢复迹象或业务恢复正常的时间
- **时间跨度分析**：从发生到恢复的总时长，识别关键时间节点

#### 二、根因推断（Root Cause Inference）
基于错误日志的模式识别、关联分析和上下文推断，找出故障的根本原因：

**分析方法**：
- 识别错误日志中的异常模式（频率突增、特定错误类型集中出现等）
- 分析错误之间的因果关系和依赖链
- 结合业务上下文判断最可能的原因

**输出要求**：
- **直接原因（Direct Cause）**：直接触发故障的表面原因
- **根本原因（Root Cause）**：深层次的系统性问题
- **置信度评估**：高/中/低，并说明依据

#### 三、故障因果链与证据链（Causal Chain & Evidence Chain）
构建完整的故障传播路径，并提供支撑推断的关键证据：

**因果链**：
描述故障从源头到最终影响的完整传播路径，格式为：
```
[故障源头] → [中间环节1] → [中间环节2] → ... → [最终表现]
```

每个环节应包含：
- **原因（Cause）**：该环节的输入事件或状态
- **结果（Effect）**：该环节导致的输出或状态变化
- **证据（Evidence）**：支撑该环节推断的关键日志条目

**证据链**：
列出支撑根因推断的关键证据，每条证据应包含：
- **时间戳**：证据产生的时间
- **证据类型**：日志条目、错误堆栈、异常信息等
- **证据内容**：具体的日志内容或错误信息
- **关联度**：直接/间接/辅助

#### 四、处置动作建议（Immediate Response Actions）
**本节重点关注：故障发生时的应急处置动作**

分类：
1. **应急止血动作**（发现故障后立即执行）：
   - 服务降级/熔断、流量切换/隔离、资源扩容等
2. **排查定位动作**（应急处置后，定位根因前）：
   - 日志检索、监控指标检查、链路追踪分析等
3. **恢复验证动作**（根因修复后，确认恢复）：
   - 功能验证、监控观察、灰度发布验证等

每个动作应包含：动作名称、执行时机、执行步骤、预期效果、注意事项。

#### 五、整改建议（Rectification Suggestions）

1. **立即处置**（1小时内）：
   - 配置调整、服务重启、临时降级方案等
2. **根因解决**（1-2周）：
   - 代码缺陷修复、异常处理完善、资源泄漏修复等
3. **架构/监控改进**（1-3个月）：
   - 引入熔断/降级机制、新增关键指标监控、优化告警规则等

#### 六、传统分析维度
1. 关键错误摘要：最重要的 5-10 个错误类型
2. 错误频率统计：按类型、时间段、服务模块等维度
3. 错误趋势识别：周期性、传播性、关联性等
4. 解决建议分类：运维（Ops）和开发（Dev）角度

### 输出格式要求

**必须使用有效的 JSON 格式输出**：

```json
{
  "summary": "故障分析总体摘要（150字以内）",

  "timeline": {
    "description": "故障时间线描述",
    "key_events": [
      {
        "time": "2026-06-14T10:30:00",
        "event_type": "first_abnormal | peak_error | recovery",
        "description": "事件描述"
      }
    ],
    "total_duration": "故障总时长"
  },

  "root_cause": {
    "direct_cause": "直接原因描述",
    "fundamental_cause": "根本原因描述",
    "confidence": "high | medium | low",
    "reasoning": "根因推断的逻辑和依据"
  },

  "causal_chain": {
    "chain_description": "因果链总体描述",
    "chain_steps": [
      {
        "step": 1,
        "cause": "故障源头或触发事件",
        "effect": "导致的后果或状态",
        "evidence": "关键证据",
        "timestamp": "时间戳"
      }
    ]
  },

  "evidence_chain": {
    "description": "证据链说明",
    "evidences": [
      {
        "timestamp": "证据时间戳",
        "evidence_type": "log | exception | metric | trace",
        "content": "证据内容",
        "relevance": "direct | indirect | supporting"
      }
    ]
  },

  "response_actions": {
    "description": "处置动作建议总述",
    "emergency_actions": [
      {
        "action_name": "动作名称",
        "timing": "执行时机",
        "steps": "执行步骤",
        "expected_effect": "预期效果",
        "notes": "注意事项"
      }
    ],
    "troubleshooting_actions": [],
    "recovery_actions": []
  },

  "remediation": {
    "immediate": [
      {
        "action": "具体行动",
        "target": "目标",
        "expected_effect": "预期效果",
        "effort_estimate": "工作量评估（人天）"
      }
    ],
    "root_cause_fix": [],
    "architecture_monitoring": []
  },

  "key_errors": [
    {
      "error_type": "NullPointerException",
      "description": "错误描述",
      "count": 456,
      "severity": "critical | high | medium | low",
      "first_occurrence": "首次出现时间",
      "sample_log": "示例日志"
    }
  ],

  "frequency_stats": {},

  "trends": [
    {
      "trend_type": "periodic | propagating | correlated",
      "description": "趋势描述",
      "evidence": "支撑数据或日志"
    }
  ],

  "ops_suggestions": [
    {
      "category": "监控 | 告警 | 配置 | 部署 | 容量规划",
      "suggestion": "具体建议内容",
      "priority": "high | medium | low"
    }
  ],

  "dev_suggestions": [
    {
      "category": "代码修复 | 异常处理 | 参数验证 | 架构优化 | 日志改进",
      "suggestion": "具体建议内容",
      "priority": "high | medium | low"
    }
  ]
}
```

### 分析原则

1. **基于证据**：所有推断必须有日志证据支撑，避免主观猜测
2. **区分概率**：对不确定的推断，明确标注置信度
3. **可操作性**：所有建议必须具体、可落地、可验证
4. **优先级明确**：区分紧急、重要、长期的改进项
5. **业务视角**：从业务影响角度评估故障严重程度

### 注意事项

- 如果日志数据不足，明确说明限制和需要进一步信息
- 如果错误模式不明确，提供多种可能性并标注概率
- 确保输出的 JSON 格式有效，便于程序解析
- 中文输出，术语准确，表达专业

---

## 支持的日志格式

```
2026-06-14 10:30:45.123 [thread-01] ERROR a1b2c3d4 com.example.Service - NullPointerException: null object
```

解析字段：

| 字段 | 说明 | 示例 |
|------|------|------|
| timestamp | 时间戳 | 2026-06-14 10:30:45.123 |
| thread_name | 线程名 | http-nio-8080-exec-1 |
| level | 日志级别 | ERROR / WARN / INFO / DEBUG / FATAL |
| trace_id | 追踪 ID | a1b2c3d4e5f6 |
| class_name | 类名 | com.example.UserService |
| message | 日志消息 | NullPointerException: null object |
| error_type | 错误类型（自动提取） | NullPointerException |
| error_message | 错误消息（自动提取） | null object |
| stack_trace | 堆栈跟踪（可选） | at com.example.Service.method() |

## 使用示例

### 示例 1：基础分析

**用户输入**："分析 /var/log/app.log 的错误日志"

**执行步骤**：
1. 调用 `parse_log_file` 工具解析日志
2. 将解析结果注入 LLM 提示词
3. LLM 生成结构化分析报告

**Agent 调用示例**：
```bash
# 步骤 1: 解析日志
python src/analyze_log.py --file /var/log/app.log

# 输出 JSON，包含统计数据、错误样本、时间线等
```

**步骤 2**: 将 JSON 作为 user_content，配合系统提示词发送给 LLM

**最终输出**：结构化 JSON 报告，包含根因分析、时间线、处置建议等。

### 示例 2：大文件分析

**用户输入**："分析这个 2GB 的日志文件，最近一小时错误很多"

**Agent 执行流程**：
1. 使用 `--chunk-size 200000` 参数调用解析脚本
2. 提取错误样本和统计信息
3. 让 LLM 聚焦分析高峰时段的错误模式

```bash
python src/analyze_log.py --file huge.log --chunk-size 200000
```

## 常见问题

### 如何支持自定义错误模式？

编辑 `src/analyze_log.py` 中的 `CUSTOM_PATTERNS` 配置，添加自定义正则：

```python
CUSTOM_PATTERNS = {
    "timeout": r"timeout|超时|Connection.*timeout",
    "auth_error": r"认证失败|token.*invalid|permission.*denied",
}
```

### 如何处理 GB 级文件？

- 减小 `--chunk-size`（建议 50000-200000）
- 脚本使用 mmap 内存映射，不会一次性加载整个文件
- 处理 2GB 文件的内存占用通常在 50-100MB

### 如何集成到不同平台？

| 平台 | 集成方式 |
|------|---------|
| Dify | 创建自定义工具 → 执行 `parse_log_file` → 注入提示词 |
| LangChain | 定义 `StructuredTool` → 调用脚本 → 构建 Prompt |
| OpenCode | 原生支持 SKILL.md → 定义 tool → 使用 skill 工具 |
| 其他 | 调用脚本获取 JSON → 填充到系统提示词 → 调用 LLM |

## 错误处理

| 场景 | 处理方式 |
|------|---------|
| 文件不存在 | 返回明确错误信息 |
| 文件过大无权限 | 自动捕获 OSError |
| 无错误日志 | 返回空统计，提示用户 |
| 解析失败行 | 跳过该行，记录计数 |
| 格式不匹配 | 尝试通用解析模式 |

## 版本信息

| 版本 | 日期 | 更新内容 |
|------|------|----------|
| 2.0.0 | 2026-06-24 | 平台无关版本，去除原项目依赖，嵌入专家提示词 |
| 1.0.0 | - | 原始 log-analyzer 版本 |
